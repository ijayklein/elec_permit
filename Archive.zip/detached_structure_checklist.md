# Detached Structure Checklist

### Blank Table
| Code | Requirement | Rationale | Verified | Notes |

### Sample Completed
| Code | Requirement | Rationale | Verified | Notes |
|------|-------------|-----------|----------|-------|
| 225.31 | Local disconnect | Safety | Y | 100A MCB at shed |
| 250.32 | GES at detached | Grounding | Y | Two rods bonded |
| 215.3 | OCPD at source | Protection | Y | Feeder breaker in house |
