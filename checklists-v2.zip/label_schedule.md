# Label Schedule

### Blank Table
| Code | Label Wording | Purpose |
|------|---------------|---------|

### Sample Completed
| Code | Label Wording | Purpose |
|------|---------------|---------|
| 230.85(E) | “EMERGENCY DISCONNECT — SERVICE DISCONNECT” | Firefighter shutoff |
| 705.10 | “CAUTION — MULTIPLE SOURCES OF POWER” | Alert personnel |
| 690.54 | “PHOTOVOLTAIC SYSTEM AC POINT OF CONNECTION” | Identify PV tie-in |
| 690.56(C) | “PV SYSTEM EQUIPPED WITH RAPID SHUTDOWN — OPERATE RAPID SHUTDOWN SWITCH TO OFF” | Firefighter safety |
