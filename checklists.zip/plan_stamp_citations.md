# Plan Stamp Code Citations

| Citation | Scope |
|----------|-------|
| 110.26 | Working space, illumination |
| 240.24 | Panel location & handle height |
| 230.85 | Emergency disconnect |
| 230.67 | Surge protection device |
| 250.94 | Intersystem bonding termination |
| 408.4 | Panel directories |
| 705.10/11/12 | PV interconnections |
| 690.12/54/56(C) | PV shutdown & labels |
| CALGreen 4.106.4.1 | EV-capable mandate |
| CRC R328 | ESS siting |
| CFC 1206 | ESS fire provisions |
